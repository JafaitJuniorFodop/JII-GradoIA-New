# JII-GradoIA
Material for the "Jornadas Iniciación a la Ingeniería" of Tecnun, School of Engineering at the University of Navarra.

Session:

1) Introduction to ML: unsupervised and supervised learning
2) Brief explanation of the k-means clustering algorithm
3) Notebook 1
4) Brief explanation of NNs: https://playground.tensorflow.org
5) Notebook 2
